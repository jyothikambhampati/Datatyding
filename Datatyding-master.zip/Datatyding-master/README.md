  ![UC3M_logo](https://www.uc3m.es/ss/Satellite?blobcol=urldata&blobkey=id&blobtable=MungoBlobs&blobwhere=1371552353583&ssbinary=true)
                                 
                                 Masters in Statistics for Data Science
                                   Course: Data Tyding and Reporting     
                                               2019
                      Authors: Kambhampati Jyothi and Luis Gonzalez Conde Sanchez Crespo
                      
                      
Introduction:

This is an application which gives information about Current weather for some specific cities. The application gives information about five days future forecast, also 3 hours weather forecast. Weather forecast detects weather automatically for cities that the user choose. There are many information in weather forecast which includes Temperature, atmospheric pressure, relative humidity, precipitation, wind speed and direction. In Addition to the forecast information, the user can explore through Maps and check the real-time temperature, rain, snow, humidity, pressure, wind force and wind direction are all in this weather application based. 

 Data source: Data is extracted from https://openweathermap.org/ using Current weather API and processed according to the application requirement.

Features:

-> Real-Time updates for Today, tommorow,5 days later in every 3 hours.

-> Weather forecast for cities which include: Sevilla,Bilbao,Vigo,Gijon,Zaragoza,Amsterdam,London,Lisbon,Paris,Barcelona,Madrid,Valencia,Mumbai,Salamanca,Toledo,Getafe,Singapore,Hong Kong,New York,Dubai,Rome,Las Vegas,Milan,Warsaw,Toronto,Miami,Buenos Aires,Rio de Janeiro,Santiago,Quito,Nairobi,Cairo,Istanbul,Berlin,Munich,Moscow,Tokyo,Delhi,Chennai,Shanghai,Melbourne,Sydney,Vienna,Budapest,Brussels,Nice,Marseille.

-> Chart to manage and view 3 hour updates and 5 day weather and on click hover it displays accurate timings and selected measure along with its units. 

->Real time weather maps with your personal blizzard & hurricane tracker: Rain, snow, clouds, Fog, sunny, Clear,Thunderstorm, Drizzle etc.

-> Weather Description in maps: City name, Cloudiness, Temperature,Temperature range,Wind speed, Atmospheric Pressure, Relative Humidity, Clouds, Sunrise and Sunset timings.

-Unit setting: Temperature(C), Time format (YYYY/MM/DD HH:MM:SS), Precipitation (mm), wind speed (m/s), pressure (hpa),Humidity(%) 

Github repository :https://github.com/jyothikambhampati/Datatyding

Check out the app @ https://weatherdata.shinyapps.io/WeatherForecast/
